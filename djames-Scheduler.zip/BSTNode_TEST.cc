#define CATCH_CONFIG_MAIN //This will make our main for us :)
#include "catch.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include "BSTNode.h"
using namespace std;

TEST_CASE("TESTING BSTNODE")
{
  BSTNode<int,int>* test_BSTNode;
 
  SECTION("Default Constructor")
    {     
	
      test_BSTNode=new BSTNode<int, int>(2,2);
      //Information to be printed if error (optional stuff)
      INFO("Using default constructor") //Displayed if fails
      
      
      
      //IF TEST FAIL -- STOP ALL TESTING
      REQUIRE(test_BSTNode->getKey() == 2); // Check if true
      REQUIRE(test_BSTNode->getValue()==2);
      REQUIRE(test_BSTNode->getLeftChild()==0);
      REQUIRE(test_BSTNode->getRightChild()==0);
      REQUIRE(test_BSTNode->getParent()==0);
    }
  
  SECTION("GET VALUE")
    {
      test_BSTNode=new BSTNode<int,int>(2,2);
      test_BSTNode->setValue(6);
      REQUIRE(test_BSTNode->getValue()==6);
    }

  SECTION("GET KEY")
    {
      test_BSTNode=new BSTNode<int,int>(2,2);
      test_BSTNode->setKey(4);
      REQUIRE(test_BSTNode->getKey()==4);
    }

    
  
  SECTION("GET LEFT CHILD")
    {
      test_BSTNode=new BSTNode<int,int>(2,2);
      BSTNode<int,int>* test_BSTNode2= new BSTNode<int,int>(3,3);
      test_BSTNode->setLeftChild(test_BSTNode2);
      REQUIRE(test_BSTNode->getLeftChild()==test_BSTNode2);
    }

  SECTION("GET RIGHT CHILD")
    {
      
      test_BSTNode=new BSTNode<int,int>(2,2);
      BSTNode<int,int>* test_BSTNode2=new BSTNode<int,int>(3,3);
      test_BSTNode->setRightChild(test_BSTNode2);
      REQUIRE(test_BSTNode->getRightChild()==test_BSTNode2);
    }
  SECTION("GET PARENT")   
    {
      test_BSTNode=new BSTNode<int,int>(2,2);
      BSTNode<int,int>* test_BSTNode2=new BSTNode<int,int>(3,3);
      test_BSTNode->setParent(test_BSTNode2);
      REQUIRE(test_BSTNode->getParent()==test_BSTNode2);
    }
  
}

// can i compare a node pointer with a null pointer?
