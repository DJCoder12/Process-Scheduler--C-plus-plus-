#define CATCH_CONFIG_MAIN //This will make our main for us :)
#include "catch.hpp"
#include <iostream>
#include "List.h"
#include <string>
#include <fstream>
using namespace std;
/*More info on Catch
Git-Page: https://github.com/philsquared/Catch
*/
#include "ArrayList.h"

// capture runs the command and remembers the return value and tells you the value you got to compare when all info is printed out in terminal

//Check is a passive version of require that tells whether a test fails but still runs everything. YOU CAN USE REQUIRE FOR EVERYTHING. CHECK THE HW TO SEE IF YOU NEED TO RESIZE THE ARRAY
TEST_CASE("TESTING ArrayList Class")
{
 
  SECTION("Default Constructor")
    {     
      ArrayList <int>test_arraylist = ArrayList<int>();

      //Information to be printed if error (optional stuff)
      INFO("Using default constructor") //Displayed if fails
      CAPTURE(test_arraylist.getCapacity()); //Display this if fails
      
      
      //IF TEST FAIL -- STOP ALL TESTING
      REQUIRE(test_arraylist.getSize() == 0); // Check if true
      REQUIRE(test_arraylist.getCapacity()==10);// Checks capacity
    }

   SECTION("CUSTOM Constructor")
    {     
      ArrayList <int>test_arraylist = ArrayList<int>(13);
      //IF TEST FAIL -- STOP ALL TESTING
      REQUIRE(test_arraylist.getSize() == 0); // Check if true
      REQUIRE(test_arraylist.getCapacity()==13);// Checks capacity
    }

   SECTION("POP BACK")
     {
       ArrayList <int>test_arraylist = ArrayList<int> ();       
       test_arraylist.pushFront(10);
       REQUIRE(test_arraylist.getSize()==1);
       REQUIRE(test_arraylist.getItem(0)==10);
       test_arraylist.pushFront(20);
       REQUIRE(test_arraylist.getItem(0)==20);
       REQUIRE(test_arraylist.getSize()==2);
       test_arraylist.popBack();
       REQUIRE(test_arraylist.getSize()==1);
       REQUIRE(test_arraylist.getItem(0)==20);
       test_arraylist.popBack();
       REQUIRE(test_arraylist.getSize()==0);
	 
     }
   SECTION("GET FRONT")
     {
       ArrayList <int>test_arraylist = ArrayList<int> ();       
       test_arraylist.pushFront(10);
       REQUIRE(test_arraylist.getSize()==1);
       REQUIRE(test_arraylist.getFront()==10);
       test_arraylist.pushFront(20);
       REQUIRE(test_arraylist.getFront()==20);
       REQUIRE(test_arraylist.getSize()==2);
     }

   SECTION("GET ITEM")
     {
       ArrayList <int>test_arraylist = ArrayList<int> ();       
       //IF TEST FAIL -- CONTINUE TESTING
       test_arraylist.pushFront(10);
       REQUIRE(test_arraylist.getSize()==1);
       REQUIRE(test_arraylist.getItem(0)==10);
       test_arraylist.pushFront(20);
       REQUIRE(test_arraylist.getItem(0)==20);
       REQUIRE(test_arraylist.getSize()==2);
     }

   SECTION("SET ITEM")
     {
        ArrayList <int>test_arraylist = ArrayList<int> ();       
       //IF TEST FAIL -- CONTINUE TESTING
       test_arraylist.pushFront(10);
       REQUIRE(test_arraylist.getSize()==1);
       test_arraylist.pushFront(20);
       test_arraylist.setItem(0,11);
       test_arraylist.setItem(1,25);
       REQUIRE(test_arraylist.getItem(0)==11);
       REQUIRE(test_arraylist.getItem(1)==25);
     }
   SECTION("PUSH FRONT")
     {
       ArrayList <int>test_arraylist = ArrayList<int> ();       
       //IF TEST FAIL -- CONTINUE TESTING
       test_arraylist.pushFront(10);
       REQUIRE(test_arraylist.getSize()==1);
       REQUIRE(test_arraylist.getItem(0)==10);
       test_arraylist.pushFront(20);
       REQUIRE(test_arraylist.getItem(0)==20);
       REQUIRE(test_arraylist.getSize()==2);
     }
   SECTION("REMOVE")
     {
       ArrayList <int>test_arraylist = ArrayList<int> ();       
       //IF TEST FAIL -- CONTINUE TESTING
       test_arraylist.pushBack(5);
       test_arraylist.pushBack(6);
       test_arraylist.pushBack(7);
       REQUIRE(test_arraylist.getSize()==3);
       REQUIRE(test_arraylist.getItem(0)==5);
       test_arraylist.remove(0);
       REQUIRE(test_arraylist.getSize()==2);
       REQUIRE(test_arraylist.getItem(0)==6);
       test_arraylist.remove(0);
       REQUIRE(test_arraylist.getItem(0)==6);
       test_arraylist.remove(0);
       REQUIRE(test_arraylist.isEmpty()==true);
     }
   SECTION("INSERTION")
     {
       ArrayList <int>test_arraylist = ArrayList<int> ();       
       //IF TEST FAIL -- CONTINUE TESTING
       REQUIRE(test_arraylist.getSize()==0);
       test_arraylist.insert(0,5);
       REQUIRE(test_arraylist.getSize()==1);
       REQUIRE(test_arraylist.getItem(0)==5);
       test_arraylist.remove(0);
       REQUIRE(test_arraylist.getSize()==0);
       
     }
   SECTION("PUSHBACK")
     {
       ArrayList <int>test_arraylist = ArrayList<int> (); 
       test_arraylist.pushBack(10);
       REQUIRE(test_arraylist.getSize()==1);
       REQUIRE(test_arraylist.getItem(0)==10);
       test_arraylist.pushBack(20);
       REQUIRE(test_arraylist.getItem(1)==20);
       REQUIRE(test_arraylist.getSize()==2);
     }
   
   SECTION("GET SIZE")
     {
       ArrayList <int>test_arraylist = ArrayList<int> (); 
       test_arraylist.pushBack(10);
       test_arraylist.pushBack(10);
       test_arraylist.pushBack(10);
       test_arraylist.pushBack(10);
       test_arraylist.pushBack(10);
       test_arraylist.pushBack(10);
       REQUIRE(test_arraylist.getSize()==6);
     }
   SECTION("IsEmpty")
     {
       ArrayList <int>test_arraylist = ArrayList<int> (); 
       test_arraylist.pushBack(10);
       test_arraylist.pushBack(20);
       test_arraylist.popBack();
       test_arraylist.popBack();
       REQUIRE(test_arraylist.isEmpty()== true);
       test_arraylist.pushFront(10);
       test_arraylist.pushFront(20);
       test_arraylist.popFront();
       test_arraylist.popFront();
       REQUIRE(test_arraylist.isEmpty()== true);
     }
   
   SECTION("RESIZE")
     {
       ArrayList <int>test_arraylist = ArrayList<int> (); 
       test_arraylist.pushBack(1);
       test_arraylist.pushBack(2);
       test_arraylist.pushBack(3);
       test_arraylist.pushBack(4);
       test_arraylist.pushBack(5);
       test_arraylist.pushBack(6);
       test_arraylist.pushBack(7);
       test_arraylist.pushBack(8);
       test_arraylist.pushBack(9);
       test_arraylist.pushBack(10);
       REQUIRE(test_arraylist.getSize()==10);
       test_arraylist.pushBack(10);
       test_arraylist.pushBack(20);
       REQUIRE(test_arraylist.getSize()==12);
       REQUIRE(test_arraylist.getCapacity()==20);      
     }
}


// if you test set and get functions in other tests that they dont have to be their own separate sections
