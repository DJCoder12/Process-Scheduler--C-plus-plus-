#ifndef BSTMultimap_H
#define BSTMultimap_H
#include "BSTNode.h"
#include "BSTForwardIterator.h"
#include <queue>
#include "BSTForwardIterator.h"
using namespace std;

template<class key_t, class val_t>
  class BSTMultimap
{
 public:
  int numItems;
  BSTNode<key_t,val_t>* root;//the root of the tree
  BSTNode<key_t,val_t>* sentinel;//this is the special no node it is set if a parent node doesnt have 1 or both of its children
  BSTMultimap();
  virtual ~BSTMultimap();
  virtual void insert(const key_t& key, const val_t& val);//creates a node and places it in the right spot in the tree
  virtual int getSize();
  virtual bool isEmpty();
  virtual void printTree();
  virtual bool contains(const key_t& key)const;
  virtual void clear();
  virtual void insertNode(BSTNode<key_t,val_t>* newNode);
  virtual void transplant(BSTNode<key_t,val_t>* x,BSTNode<key_t,val_t>* y);
  //virtual BSTForwardIterator<key_t, val_t> getSuccessor(BSTForwardIterator<key_t,val_t>&pos);
  virtual BSTForwardIterator<key_t,val_t>* getTreeMin(BSTForwardIterator<key_t,val_t>* x);
  virtual BSTForwardIterator<key_t, val_t> getMin() const;
  virtual BSTForwardIterator<key_t, val_t> getMax() const;
  virtual BSTForwardIterator<key_t, val_t> findFirst(const key_t& key);
  virtual BSTForwardIterator<key_t,val_t> findLast(const key_t& key)const;
  virtual BSTForwardIterator<key_t,val_t>remove(const BSTForwardIterator<key_t,val_t>&pos);
  //virtual BSTNode<key_t,val_t> getTreeMin(BSTNode<key_t,val_t>* x);
};

template <class key_t, class val_t>
  BSTMultimap<key_t,val_t>:: BSTMultimap()
{

  sentinel=0;
  root=sentinel;
  numItems=0;
}

template<class key_t, class val_t>
  BSTMultimap<key_t,val_t>::~BSTMultimap()
{
  clear();
}
  





template <class key_t, class val_t>
  void BSTMultimap<key_t,val_t>::insert(const key_t& key, const val_t& val)
{
  

  BSTNode<key_t,val_t>* newNode=new BSTNode<key_t,val_t>(key,val);
  insertNode(newNode);
  numItems++;
}








template<class key_t, class val_t>
void BSTMultimap<key_t, val_t>:: printTree()
{
  queue< BSTNode<key_t, val_t>* >nodeHolder;
  nodeHolder.push(root);

  while(!nodeHolder.empty())
    {
      BSTNode<key_t, val_t>* node=nodeHolder.front();
      if(node->getLeftChild() != sentinel)
	{
	  nodeHolder.push(node->getLeftChild());
	}
      if(node->getRightChild() != sentinel)
	{
	  nodeHolder.push(node->getRightChild());
	}
      
      nodeHolder.pop();
    }
}











template<class key_t,class val_t>
  void BSTMultimap<key_t,val_t>:: clear()
{
  if (numItems==0)
    {
      return;
    }
  queue< BSTNode<key_t, val_t>* >nodeHolder;
  nodeHolder.push(root);

  while(!nodeHolder.empty())
    {
      BSTNode<key_t, val_t>* node=nodeHolder.front();
      nodeHolder.front();
      

      if(node->getLeftChild() != sentinel)
	{
	  nodeHolder.push(node->getLeftChild());
	}
      if(node->getRightChild() != sentinel)
	{
	  nodeHolder.push(node->getRightChild());
	}
      delete node;      
    }
}









    
template <class key_t, class val_t>
  int BSTMultimap<key_t, val_t>::getSize()
{
  return numItems;
}














template <class key_t, class val_t>
  bool BSTMultimap<key_t,val_t>::isEmpty()
{
  if (numItems==0)
    {
      return true;
    }
  else 
    {
      return false;
    }
}













template<class key_t,class val_t>
  bool BSTMultimap<key_t,val_t>:: contains(const key_t& key)const
{
  //BSTNode<key_t,val_t>* newNode=new BSTNode<key_t,val_t>(key,0);
  BSTNode<key_t,val_t>* leadNode=root;
  while(leadNode!=sentinel)//not sure what my stop condition should be
    {
      if(key==leadNode->getKey())
	{
	  return true;
	}
      if(key<leadNode->getKey())
	{
	  leadNode=leadNode->getLeftChild();
	  
	}
      else
	{
	  leadNode=leadNode->getRightChild();
	}
    }
  return false;
}













//virtual BSTForwardIterator<key_t, val_t> getMin() const;
template<class key_t,class val_t>
  BSTForwardIterator<key_t,val_t> BSTMultimap<key_t,val_t>:: getMin() const
{
  if (numItems==0)
    {
      BSTNode<key_t,val_t>* minimumNode=root;
      BSTForwardIterator<key_t, val_t> minimumIter(minimumNode,0);
      return minimumIter;
    }
  else
    {
      BSTNode<key_t, val_t>* minimumNode=root;
      while(minimumNode->getLeftChild()!=sentinel)
	{
	  minimumNode=minimumNode->getLeftChild();
	}
      BSTForwardIterator<key_t,val_t>minimumIter(minimumNode, sentinel);
      return minimumIter;
    }
}
















template<class key_t,class val_t>
  BSTForwardIterator<key_t,val_t> BSTMultimap<key_t,val_t>:: getMax() const      
{
  if (numItems==0)
    {
      BSTNode<key_t,val_t>* maximumNode=root;
      BSTForwardIterator<key_t, val_t> maximumIter(maximumNode,sentinel);
      return maximumIter;
    }
  else
    {
      BSTNode<key_t, val_t>* maximumNode=root;
      while(maximumNode->getRightChild()!=sentinel)
	{
	  maximumNode=maximumNode->getRightChild();
	}
      BSTForwardIterator<key_t,val_t>maximumIter(maximumNode, sentinel);
      return maximumIter;
    }
}



























template<class key_t,class val_t>
  BSTForwardIterator<key_t,val_t> BSTMultimap<key_t,val_t>:: findFirst(const key_t& key) 
{
  
  BSTNode<key_t,val_t>* firstNode=root;
  BSTForwardIterator<key_t, val_t> firstFinderIter(firstNode,0);
  while(firstNode->getKey()!= key)
    {
      if(firstNode->getKey()<key)
	{
	  firstNode=firstNode->getRightChild();
	  
	}
      else if (firstNode->getKey()>key)
	{
	  firstNode=firstNode->getLeftChild();
	}      
    }
  BSTForwardIterator<key_t, val_t> FoundIter(firstNode,0);
  return FoundIter;
}


















template<class key_t,class val_t>
  BSTForwardIterator<key_t,val_t> BSTMultimap<key_t,val_t>:: findLast(const key_t& key) const
{
  BSTNode<key_t,val_t>* firstNode=root;
  BSTNode<key_t,val_t>* finalNode;
  BSTForwardIterator<key_t, val_t> firstLastIter(firstNode,0);
  while(firstNode!=finalNode)
    {
      if(firstNode->getKey()<key)
	{
	  firstNode=firstNode->getRightChild();
	  
	}
      else if (firstNode->getKey()>key)
	{
	  firstNode=firstNode->getLeftChild();
	}  
      else if (firstNode->getKey()==key && firstNode->getRightChild()!=sentinel)
	{
	  finalNode=firstNode;
	  firstNode=firstNode->getRightChild();
	}
      else
	{
	  finalNode=firstNode;
	}
    }
  BSTForwardIterator<key_t, val_t> FoundIter(finalNode,0); 
  return FoundIter;
}














template<class key_t, class val_t>
  void BSTMultimap<key_t,val_t>:: insertNode(BSTNode<key_t,val_t>* newNode)
{
  //BSTNode<key_t,val_t>* newNode=new BSTNode<key_t,val_t>(key,val);
  BSTNode<key_t,val_t>* leadNode=root;
  BSTNode<key_t,val_t>* runner=sentinel;
  
  
  if(numItems==0)
    {
      root=newNode;
      root->setLeftChild(sentinel);
      root->setRightChild(sentinel);
      return;
    }
  else
    {
      while(leadNode!=sentinel)
        
	{
	  runner=leadNode;
	  if(newNode->getKey()<leadNode->getKey())
	    {
	      leadNode=leadNode->getLeftChild();
	    }
	  else
	    {
	      leadNode=leadNode->getRightChild();
	    }
	}
      if(runner==sentinel)
	{
	  root=newNode;
	}
      else if(newNode->getKey()<runner->getKey())
	{
	  runner->setLeftChild(newNode);
	  newNode->setParent(runner);
	  newNode->setRightChild(sentinel);
	} 
	
      else
	{
	  runner->setRightChild(newNode);
	  newNode->setParent(runner);
	  newNode->setLeftChild(sentinel);	    
	}
    }
}

















//virtual void transplant(BSTNode<key_t,val_t>* x);
//Transplant moves entire subtrees 
// virtual BSTForwardIterator<key_t,val_t>remove(const BSTForwardIterator<key_t,val_t>&pos)
// pos is a reference to an iterator that points to a current node that I want to get rid of.
// follow through with getsuccessor and changing parent children to accomodate successor.





//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
template<class key_t, class val_t>
  BSTForwardIterator<key_t, val_t> BSTMultimap<key_t,val_t>::remove(const BSTForwardIterator<key_t,val_t>&pos)
{
 
  if (pos.current->getLeftChild()==sentinel)
    {
      
      transplant(pos.current,pos.current->getRightChild());
    }
  else if(pos.current->getRightChild()==sentinel)
    {
      
      transplant(pos.current,pos.current->getLeftChild());
      
    }
  else
    {
     
      BSTNode<key_t,val_t>* node=this->sentinel;
      BSTForwardIterator<key_t,val_t> treeMin= pos;
      treeMin.next();

 
      if (treeMin.current->getParent()!=pos.current)
	{	  
	  transplant(treeMin.current,treeMin.current->getRightChild());	  
	  treeMin.current->setRightChild(pos.current->getRightChild());
	  treeMin.current->getRightChild()->setParent(treeMin.current);	  
	}
      transplant(pos.current,treeMin.current);
      treeMin.current->setLeftChild(pos.current->getLeftChild());
      treeMin.current->getLeftChild()->setParent(treeMin.current);
    }
  numItems--;
  return pos;
}
  



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////


template<class key_t,class val_t>
  void BSTMultimap<key_t,val_t>::transplant(BSTNode<key_t,val_t>* x, BSTNode<key_t,val_t>* y)
{
  
  if (x->getParent()==sentinel)
    {
      root=y;
    }
  else if(x==x->getParent()->getLeftChild())
    {
      
      x->getParent()->setLeftChild(y);
    }
  else
    {
      
      x->getParent()->setRightChild(y);
    }
  if(y!=sentinel)
    {
      
      y->setParent(x->getParent());
    }

}










//virtual BSTForwardIterator<key_t,val_t>* getTreeMin(BSTForwardIterator<key_t,val_t>&pos);

template<class key_t, class val_t>
  BSTForwardIterator<key_t,val_t>* BSTMultimap<key_t,val_t>:: getTreeMin(BSTForwardIterator<key_t,val_t>*x)
{
  while(x->current->getLeftChild()!=sentinel)
    {
      x->current=x->current->getLeftChild();
    }
  return (x);
}







#endif


// HOW DO I FIX LINE 398 it is breaking my remove
  /*
  BSTNode<key_t,val_t>* leadNode=root;
  BSTNode<key_t,val_t>* runner=sentinel;
  //dont do setting of newNode in your while loop. Use the while loop to find the correct location for the newNOde.
  // you only add to the end of the tree never in the middle.
  if(numItems==0)
    {
      root=newNode;
      return;
    }
  else
    {
      while(leadNode!=sentinel)
	//not sure what my stop condition should be
	{
	  runner=leadNode;
	  if(newNode->getKey()<leadNode->getKey())
	    {
	      leadNode=leadNode->getLeftChild();
	    }
	  else
	    {
	      leadNode=leadNode->getRightChild();
	    }
	}
      newNode->setParent(runner);
      if (runner==sentinel)
	{
	  root=newNode;
	}
      else if(newNode->getKey()<runner->getKey())
	{
	  runner->setLeftChild(newNode);
	  newNode->setParent(runner);
	}
      else
	{
	  runner->setRightChild(newNode);
	  newNode->setParent(runner);
	}
    }
  */


// INSERT HAS A SEG FAULT FIX IT




//virtual BSTForwardIterator<key_t, val_t> getSuccessor(BSTForwardIterator<key_t,val_t>&pos)
/*template<class key_t,class val_t>
  BSTForwardIterator<key_t,val_t>& BSTMultimap<key_t,val_t>::getSuccessor(BSTForwardIterator<key_t,val_t>&pos)
{
  if(pos.current->getRightChild()!=sentinel)
    {
      return getTreeMin(pos);
    }
  BSTNode<key_t,val_t>* successor=pos.current->getParent();
  while(successor!=sentinel && pos.current==successor->getRightChild())
    {
      pos.current=successor;
      successor=successor->getParent();
    }
  return pos;
}
*/
