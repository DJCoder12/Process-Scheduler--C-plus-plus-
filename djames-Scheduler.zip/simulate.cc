#include "Scheduler.h"
#include "Process.h"
#include <iostream>
#include <chrono>

using namespace std;

double* simulate(Scheduler* sched, int numCPUBound, int numIOBound, int numCycles)
{
  // creates an empty array list of processes
   ArrayList<Process*> cpuProcs;

   // a loop that adds cpu bound processes to the arraylist and adds a new process to the scheduler
   for(int i = 0; i < numCPUBound; i++)
   {
      cpuProcs.pushBack(new CPUBoundProcess(i));
      sched->addProcess(cpuProcs.getBack());
   }
   
   // creates an arraylist for I/O Bound processes 
   ArrayList<Process*> ioProcs;

   // a loop that adds io processes to the io arraylist and adds the last io process in the io array list to the scheduler.
   for(int i = 0; i < numIOBound; i++)
   {
      ioProcs.pushBack(new IOBoundProcess(i+numCPUBound));
      sched->addProcess(ioProcs.getBack());
   }
   // sets up the important variables for the main loop of the function which will determine when the function will begin and end. 
   auto start = chrono::system_clock::now();
   int numSchedules = 0;
   int curCycle = 0;

   //main loop of the function
   while(curCycle < numCycles)
   {
     //gets the next process from the schedule
      Process* p = sched->popNext(curCycle);
      numSchedules++;
      if(p != 0)
      {
	 curCycle += p->simulate(curCycle, 10);
	 sched->addProcess(p);
      }
      else
      {
	//this brings the loop closer to ending if a null pointer is pulled from the schedule
	 curCycle += 10;
      }
   }
   //accesses the variables that will serve as my start and stop variables for recording runtimes
   auto end = chrono::system_clock::now();
   auto dur = end - start;
   auto durNS = chrono::duration_cast<chrono::nanoseconds>(dur);

   double cpuCPUTime = 0;
   double cpuWaitTime = 0;
   for(int i = 0; i < cpuProcs.getSize(); i++)
   {
      Process* p = cpuProcs.getItem(i);
      cpuCPUTime += p->getCPUTime();
      cpuWaitTime += p->getWaitTime(curCycle);
      delete p;
   }

   double ioCPUTime = 0;
   double ioWaitTime = 0;
   for(int i = 0; i < ioProcs.getSize(); i++)
   {
     // This loop creates a process temporarily to hold the information pulled off of the schedule and calculates both the ioCPUTime and the ioWaitTime before deling said process
      Process* p = ioProcs.getItem(i);
      ioCPUTime += p->getCPUTime();
      ioWaitTime += p->getWaitTime(curCycle);
      delete p;
   }
   //calculates the results that will printed to the terminal
   double* results = new double[5];
   results[0] = double(durNS.count())/numSchedules;
   results[1] = cpuCPUTime/numCPUBound;
   results[2] = cpuWaitTime/numCPUBound;
   results[3] = ioCPUTime/numIOBound;
   results[4] = ioWaitTime/numIOBound;
   return results;
}


