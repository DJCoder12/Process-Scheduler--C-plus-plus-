#define CATCH_CONFIG_MAIN //This will make our main for us :)
#include "catch.hpp"
#include <string>
#include <iostream>
#include "Scheduler.h"
#include "Process.h"

using namespace std;
/*More info on Catch
Git-Page: https://github.com/philsquared/Catch
*/

//What are we testing today?

// capture runs the command and remembers the return value and tells you the value you got to compare when all info is printed out in terminal

//Check is a passive version of require that tells whether a test fails but still runs everything. YOU CAN USE REQUIRE FOR EVERYTHING. CHECK THE HW TO SEE IF YOU NEED TO RESIZE THE ARRAY
TEST_CASE("TESTING Round Robin Class")
{

SECTION("Default Constructor")
{     
//RoundRobin test_roundrobin; 
}

/*
SECTION("ADD PROCESS")
{
RoundRobin test_roundrobin;
IOBoundProcess * test_IOBoundProcess =new IOBoundProcess(56);
test_roundrobin.addProcess(test_IOBoundProcess);
delete test_IOBoundProcess;
      
      
    }


SECTION("POP NEXT")
{
      RoundRobin test_roundrobin = RoundRobin();
      IOBoundProcess test_IOBoundProcess =IOBoundProcess(56);
      test_roundrobin.addProcess(test_IOBoundProcess);
      REQUIRE(test_roundrobin.popNext()==test_IOBoundProcess);
}	      
	
*/  
}
  

