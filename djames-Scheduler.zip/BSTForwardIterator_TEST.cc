#define CATCH_CONFIG_MAIN //This will make our main for us :)
#include "catch.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include "BSTMultimap.h"
#include "BSTForwardIterator.h"

using namespace std;

TEST_CASE("TESTING BSTFORWARDITERATOR")
{
   
  
  SECTION("Default Constructor")
    {
      BSTMultimap<int,int>*test_BSTMultimap=new BSTMultimap<int,int>();
      test_BSTMultimap->insert(3,3);
      BSTForwardIterator<int, int> test_BSTForwardIterator(test_BSTMultimap->root,0);
      REQUIRE(test_BSTForwardIterator.getValue()==3);
      REQUIRE(test_BSTForwardIterator.getKey()==3);
      
      
	//new BSTForwardIterator<int,int>(,sentinel)
	
    }
  SECTION("NEXT")
    {
      BSTMultimap<int,int>*test_BSTMultimap=new BSTMultimap<int,int>();     
      test_BSTMultimap->insert(4,4);
      test_BSTMultimap->insert(2,2);
      test_BSTMultimap->insert(6,6);
      test_BSTMultimap->insert(1,1);
      test_BSTMultimap->insert(3,3);
      test_BSTMultimap->insert(5,5);
      test_BSTMultimap->insert(7,7);
      cout<< "insert works"<<endl;
      BSTForwardIterator<int, int> test_BSTForwardIterator(test_BSTMultimap->root,0);
      test_BSTForwardIterator.next();

      REQUIRE(test_BSTMultimap->root->getValue()==5);
    }

  /*
  SECTION("isPastEnd")
    {
      BSTMultimap<int,int>*test_BSTMultimap=new BSTMultimap<int,int>();
      BSTForwardIterator<int, int> test_BSTForwardIterator(test_BSTMultimap->root,0);
      test_BSTMultimap->insert(4,4);
      test_BSTMultimap->insert(2,2);
      test_BSTMultimap->insert(6,6);
      test_BSTForwardIterator.next();
      test_BSTForwardIterator.next();
      REQUIRE(test_BSTForwardIterator.isPastEnd()==true);
    }
  */
}
