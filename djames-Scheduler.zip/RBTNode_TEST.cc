#define CATCH_CONFIG_MAIN //This will make our main for us :)
#include "catch.hpp"
#include <iostream>
#include "List.h"
#include <string>
#include <fstream>
using namespace std;
/*More info on Catch
Git-Page: https://github.com/philsquared/Catch
*/
#include "RBTNode.h"

// capture runs the command and remembers the return value and tells you the value you got to compare when all info is printed out in terminal

//Check is a passive version of require that tells whether a test fails but still runs everything. YOU CAN USE REQUIRE FOR EVERYTHING. CHECK THE HW TO SEE IF YOU NEED TO RESIZE THE ARRAY
TEST_CASE("TESTING RBTMultimap Class")
{
 
  SECTION("Default Constructor")
    {     
      RBTNode<int,int>* test_Node= new RBTNode<int,int>(7,7,true);
      REQUIRE(test_Node->getColor()==true);
      REQUIRE(test_Node->getKey()==7);
      REQUIRE(test_Node->getValue()==7);
    }
}
