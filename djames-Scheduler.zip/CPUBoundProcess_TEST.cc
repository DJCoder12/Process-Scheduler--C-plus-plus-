
#define CATCH_CONFIG_MAIN //This will make our main for us :)
#include "catch.hpp"
#include <iostream>
#include "List.h"
#include <string>
#include <fstream>
using namespace std;
/*More info on Catch
Git-Page: https://github.com/philsquared/Catch
*/

//What are we testing today?
#include "Process.cc"

// capture runs the command and remembers the return value and tells you the value you got to compare when all info is printed out in terminal

//Check is a passive version of require that tells whether a test fails but still runs everything. YOU CAN USE REQUIRE FOR EVERYTHING. CHECK THE HW TO SEE IF YOU NEED TO RESIZE THE ARRAY


// if you test set and get functions in other tests that they dont have to be their own separate sections
TEST_CASE("TESTING LinkedList Class")
{
  
  SECTION("Default Constructor")
    {     
      CPUBoundProcess test_CPUBoundProcess =CPUBoundProcess(1);
      //Information to be printed if error (optional stuff)
      INFO("Using default constructor") //Displayed if fails
	
	
	//IF TEST FAIL -- STOP ALL TESTING
	REQUIRE(test_CPUBoundProcess.getCPUTime()==0);
      REQUIRE(test_CPUBoundProcess.getWaitTime(0)==0);
	
      
    }
  SECTION("GET ID")
    {
       CPUBoundProcess test_CPUBoundProcess =CPUBoundProcess(1);
       REQUIRE(test_CPUBoundProcess.getID()==1);
    }
  SECTION("isBlocked")
    {
      CPUBoundProcess test_CPUBoundProcess =CPUBoundProcess(1);
      REQUIRE(test_CPUBoundProcess.isBlocked(10)==false);
    }
  SECTION("SIMULATE")
    {
      CPUBoundProcess test_CPUBoundProcess =CPUBoundProcess(1);
      test_CPUBoundProcess.simulate(100, 100);
      // what does this equal
    }
}
