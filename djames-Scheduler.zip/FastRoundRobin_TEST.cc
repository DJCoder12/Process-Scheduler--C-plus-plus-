#define CATCH_CONFIG_MAIN //This will make our main for us :)
#include "catch.hpp"
#include <string>
#include <iostream>
#include "Scheduler.cc"
#include <string>
using namespace std;
/*More info on Catch
Git-Page: https://github.com/philsquared/Catch
*/

//What are we testing today?

// capture runs the command and remembers the return value and tells you the value you got to compare when all info is printed out in terminal

//Check is a passive version of require that tells whether a test fails but still runs everything. YOU CAN USE REQUIRE FOR EVERYTHING. CHECK THE HW TO SEE IF YOU NEED TO RESIZE THE ARRAY
TEST_CASE("TESTING Fast Round Robin Class")
{
 
  SECTION("Default Constructor")
    {     
      FastRoundRobin test_fastroundrobin = FastRoundRobin(); 
    }

  SECTION("ADD PROCESS")
    {
      FastRoundRobin test_fastroundrobin = FastRoundRobin();
      IOBoundProcess test_IOBoundProcess =IOBoundProcess(56);
      test_fastroundrobin.addProcess(test_IOBoundProcess);
            
    }
  
  SECTION("POP NEXT")
    {
      FastRoundRobin test_fastroundrobin = FastRoundRobin();
      IOBoundProcess test_IOBoundProcess =IOBoundProcess(56);
      test_fastroundrobin.addProcess(test_IOBoundProcess);
      REQURIE(test_fastroundrobin.popNext()==test_IOBoundProcess);
    }
  
  
}
