#include "Scheduler.h"
using namespace std;
  // Initialize procQueue as an empty ArrayList

RoundRobin::RoundRobin()
    {
      procQueue=new ArrayList<Process*>();
    }
  
  //deletes procQueue(not its contents!)
  //does this work?
  RoundRobin::~RoundRobin()
  {
    delete procQueue;
  }

  // adds the given process to the back of proQueue
  void RoundRobin::addProcess(Process* proc)
  {
    procQueue->pushBack(proc);
  }

  // returns the first un-blocked process in the queue (moving any blocked processes to the back of the queue or zero if all processes are blocked)



Process* RoundRobin::popNext(int curCycle)
{
  for (int i=0;i<procQueue->getSize();i++)
    {
      Process* pro=procQueue->getItem(i);
      procQueue->pushBack(pro);
      if(pro->isBlocked(curCycle)==false)
	{
	  return pro;
	}
    }
  return 0;
};

//////////////////////////////////////////////////////////////////////
//Build fast round robin here
// Initialize procQueue as an empty ArrayList
FastRoundRobin::FastRoundRobin()
    {
      processQueue=new LinkedList<Process*>();
    }
  
  //deletes procQueue(not its contents!)
  //does this work?
FastRoundRobin::~FastRoundRobin()
  {
    delete processQueue;
  }

  // adds the given process to the back of proQueue
void FastRoundRobin::addProcess(Process* proc)
  {
    processQueue->pushBack(proc);
  }

  // returns the first un-blocked process in the queue (moving any blocked processes to the back of the queue or zero if all processes are blocked)



Process* FastRoundRobin::popNext(int curCycle)
  {
    for (int i=0;i<processQueue->getSize();i++)
      {
	Process* pro=processQueue->getItem(i);
	processQueue->pushBack(pro);
	if(pro->isBlocked(curCycle)==false)
	  {
	    return pro;
	  }

      }
    return 0;
  }

////////////////////////////////////////////////////////////////////////////////
CompletelyFair::CompletelyFair()
    {
      procTree=new BSTMultimap<int, Process*>();
    }
  
  //deletes procQueue(not its contents!)
  //does this work?
CompletelyFair::~CompletelyFair()
  {
    delete procTree;
  }

  // adds the given process to the back of proQueue
void CompletelyFair::addProcess(Process* proc)
  {
    BSTNode<int,Process*>* newNode=new BSTNode<int,Process*>(proc->getCPUTime(),proc);
    procTree->insertNode(newNode);
  }

  // returns the first un-blocked process in the queue (moving any blocked processes to the back of the queue or zero if all processes are blocked)



Process* CompletelyFair::popNext(int curCycle)
  {
    BSTForwardIterator<int,Process*> popIter(procTree->root,0);
    popIter=procTree->getMin();
    while(popIter.getValue()->isBlocked(curCycle)==true)
      {
	popIter.next();
      }
    Process* removedProcess=popIter.getValue();
    procTree->remove(popIter);
    
    return removedProcess;
  }

//////////////////////////////////////////////////////////////////////////
FastCompletelyFair::FastCompletelyFair()
    {
      //dynamic_cast<RBTNode<key_t,val_t> * >(this->root)->setColor(false);
      delete procTree;
      procTree=new RBTMultimap<int,Process*> ();
    }

// check anything that would involve changes via inheritance.
  //deletes procTree(not its contents!)
  //does this work?
  

