#define CATCH_CONFIG_MAIN //This will make our main for us :)
#include "catch.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include "BSTMultimap.h"
#include "BSTForwardIterator.h"
using namespace std;

TEST_CASE("TESTING BSTMultimap")
{
   
  
  SECTION("Default Constructor")
    {
      BSTMultimap<int,int>*test_BSTMultimap=new BSTMultimap<int,int>();
      //Information to be printed if error (optional stuff)
      //INFO("Using default constructor") //Displayed if fails
      
      //IF TEST FAIL -- STOP ALL TESTING
      //REQUIRE(test_BSTMultimap->sentinel->getKey() == 0); // Check if true
      //REQUIRE(test_BSTMultimap->sentinel->getValue()==0);
      REQUIRE(test_BSTMultimap->sentinel==test_BSTMultimap->root);
      REQUIRE(test_BSTMultimap->sentinel==0);
      
    }
  SECTION("INSERT")
    {
      BSTMultimap<int,int>*test_BSTMultimap=new BSTMultimap<int,int>();
      test_BSTMultimap->insert(5,5);
      REQUIRE(test_BSTMultimap->root->getKey()==5);
      REQUIRE(test_BSTMultimap->root->getValue()==5);
      test_BSTMultimap->insert(2,2);
      BSTNode<int,int>* leftChild=test_BSTMultimap->root->getLeftChild();
      REQUIRE(leftChild->getKey()==2);
      REQUIRE(leftChild->getValue()==2);
      REQUIRE(test_BSTMultimap->root->getKey() == 5);
      REQUIRE(test_BSTMultimap->root->getValue() ==5);
      test_BSTMultimap->insert(6,6);
      BSTNode<int,int>* rightChild=test_BSTMultimap->root->getRightChild();
      REQUIRE(rightChild->getKey()==6);
      REQUIRE(rightChild->getValue()==6);
      
    }
  SECTION("REMOVE")
    {
      BSTMultimap<int,int>*test_BSTMultimap=new BSTMultimap<int,int>();
      test_BSTMultimap->insert(4,4);
      test_BSTMultimap->insert(2,2);
      test_BSTMultimap->insert(6,6);
      test_BSTMultimap->insert(1,1);
      test_BSTMultimap->insert(3,3);
      test_BSTMultimap->insert(5,5);
      test_BSTMultimap->insert(7,7);
   
        
      BSTForwardIterator<int,int> pos(test_BSTMultimap->root,0);
      test_BSTMultimap->remove(pos);
      REQUIRE(test_BSTMultimap->getSize()==6);
      REQUIRE(test_BSTMultimap->root->getKey()==5);
    }

  SECTION("FindFirst")
    {
      BSTMultimap<int,int>* test_BSTMultimap=new BSTMultimap<int,int>();
      test_BSTMultimap->insert(4,4);
      test_BSTMultimap->insert(2,2);
      test_BSTMultimap->insert(6,6);
      test_BSTMultimap->insert(1,1);
      test_BSTMultimap->insert(3,3);
      test_BSTMultimap->insert(5,5);
      test_BSTMultimap->insert(7,7);
      BSTForwardIterator<int,int> pos(test_BSTMultimap->root,0);
      pos=test_BSTMultimap->findFirst(5);
      REQUIRE(pos.getKey()==5);
    }




  // DOES THIS TEST REALLY WORK
  SECTION("FindLast")
    {
      BSTMultimap<int,int>* test_BSTMultimap=new BSTMultimap<int,int>();
      test_BSTMultimap->insert(4,4);
      test_BSTMultimap->insert(2,2);
      test_BSTMultimap->insert(5,6);
      test_BSTMultimap->insert(5,5);

      BSTForwardIterator<int,int> pos(test_BSTMultimap->root,0);
      pos=test_BSTMultimap->findLast(5);
      REQUIRE(pos.getValue()==5);
    }


  SECTION("GetMax")
    {
      BSTMultimap<int,int>* test_BSTMultimap=new BSTMultimap<int,int>();
      test_BSTMultimap->insert(4,4);
      test_BSTMultimap->insert(2,2);
      test_BSTMultimap->insert(6,6);
      test_BSTMultimap->insert(1,1);
      test_BSTMultimap->insert(3,3);
      test_BSTMultimap->insert(5,5);
      test_BSTMultimap->insert(7,7);

      BSTForwardIterator<int,int> pos(test_BSTMultimap->root,0);
      pos=test_BSTMultimap->getMax();
      REQUIRE(pos.getValue()==7);
    }

  SECTION("GetMin")
    {
      BSTMultimap<int,int>* test_BSTMultimap=new BSTMultimap<int,int>();
      test_BSTMultimap->insert(4,4);
      test_BSTMultimap->insert(2,2);
      test_BSTMultimap->insert(6,6);
      test_BSTMultimap->insert(1,1);
      test_BSTMultimap->insert(3,3);
      test_BSTMultimap->insert(5,5);
      test_BSTMultimap->insert(7,7);

      BSTForwardIterator<int,int> pos(test_BSTMultimap->root,0);
      pos=test_BSTMultimap->getMin();
      REQUIRE(pos.getValue()==1);
    }
  SECTION("GetMax")
    {
      BSTMultimap<int,int>* test_BSTMultimap=new BSTMultimap<int,int>();
      test_BSTMultimap->insert(4,4);
      test_BSTMultimap->insert(2,2);
      test_BSTMultimap->insert(6,6);
      test_BSTMultimap->insert(1,1);
      test_BSTMultimap->insert(3,3);
      test_BSTMultimap->insert(5,5);
      test_BSTMultimap->insert(7,7);

      BSTForwardIterator<int,int> pos(test_BSTMultimap->root,0);
      pos=test_BSTMultimap->getMax();
      REQUIRE(pos.getValue()==7);
    }
}
