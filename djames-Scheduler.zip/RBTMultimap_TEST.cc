#define CATCH_CONFIG_MAIN //This will make our main for us :)
#include "catch.hpp"
#include <iostream>
#include "List.h"
#include <string>
#include <fstream>
using namespace std;
/*More info on Catch
Git-Page: https://github.com/philsquared/Catch
*/
#include "RBTMultimap.h"
#include "RBTNode.h"
#include "BSTMultimap.h"
// capture runs the command and remembers the return value and tells you the value you got to compare when all info is printed out in terminal

//Check is a passive version of require that tells whether a test fails but still runs everything. YOU CAN USE REQUIRE FOR EVERYTHING. CHECK THE HW TO SEE IF YOU NEED TO RESIZE THE ARRAY
TEST_CASE("TESTING RBTMultimap Class")
{
 
  SECTION("Default Constructor")
    {  
      
      RBTMultimap <int,int> test_rbtmultimap= RBTMultimap<int,int>();
      REQUIRE(test_rbtmultimap.root==test_rbtmultimap.sentinel);  
      bool color=dynamic_cast<RBTNode<int,int> * >(test_rbtmultimap.root)->getColor();
      REQUIRE(color==true);
    }
  SECTION("INSERT")
    {
      RBTMultimap <int,int>* test_rbtmultimap= new RBTMultimap<int,int>(); 
      test_rbtmultimap->insert(1,1);
     
      REQUIRE(test_rbtmultimap->root->getValue()==1);
      
      test_rbtmultimap->insert(2,2);
      test_rbtmultimap->insert(3,3);
      test_rbtmultimap->insert(4,4);
      test_rbtmultimap->insert(5,5);
      //test_rbtmultimap->insert(6,6);
      //test_rbtmultimap->insert(7,7);
      
      //REQUIRE(test_rbtmultimap->root->getValue()==4);
    }

 
}
  
