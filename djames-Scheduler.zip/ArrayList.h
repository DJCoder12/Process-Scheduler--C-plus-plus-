#ifndef ARRAY_LIST_H
#define ARRAY_LIST_H
#include <iostream>
#include "List.h"
#include <string>
#include <fstream>
using namespace std;
template <class item_t>
class ArrayList: public List<item_t> // why is this wrong syntax?
//Tells compiler that list is a template class that requires a template object.
{

 private:
  void resize();



  protected:
  item_t* items;
  int size;
  int capacity;
 
  public:
   //Creates an empty list with capacity 10
   ArrayList();
   //Creates a list with the given capacity
   ArrayList(int capacity);
   ~ArrayList();
   //void resize();
   //Pushes item to the back of the list
   virtual void pushBack(const item_t& item);   


   //Removes, but does not return, the last item
   virtual void popBack();


   //Returns a reference to the last item (does not remove it).
   virtual const item_t& getBack() const; 

 
   //Pushes item to the front of the list
   virtual void pushFront(const item_t& item);
   //Removes, but does not return, the first item
   virtual void popFront();
   //Returns a reference to the first item (does not remove it).
   virtual const item_t& getFront() const;
   //Returns a reference to the item at the given index
   virtual const item_t& getItem(int index) const;
   //Sets the item at the given index
   virtual void setItem(int index, const item_t& item);
   //Inserts the given item at the given index
   //(items at index or beyond shift up one position)
   //Inserting just past the last element (i.e. position
   //size) shoud be equivalent to pushBack.
   virtual void insert(int index, const item_t& item);
   //Removes the item at the given index
   //(items beyond index shift down one position)
   virtual void remove(int index);
   //Returns the number of items in the list
   virtual int getSize() const;
   //Returns true if the list is empty (false otherwise)
   virtual bool isEmpty() const;
   //Returns the size of the array that contains the list
   virtual int getCapacity() const;
};



template <class item_t>
ArrayList<item_t>::ArrayList()
{
  size=0;
  capacity=10;
  items=new item_t[capacity];  
}

template<class item_t>
ArrayList<item_t>::ArrayList(int c)
{
  size=0;
  capacity=c;
  items=new item_t[capacity];
}


template <class item_t>
ArrayList<item_t>::~ArrayList()
{
  delete [] items;
}






template<class item_t>
int ArrayList<item_t>::getSize() const
{
  return size;
}






template<class item_t>
void ArrayList<item_t>::resize()
{
  item_t* newItems;
  if (size==capacity)
    {
      capacity*=2;
      newItems=new item_t[capacity];
      for (int i=0;i<size;i++)
	{
	  newItems[i]=items[i];
	}    
      delete [] items;
      items=newItems;  
    }
}








template<class item_t>
int ArrayList<item_t>::getCapacity() const
{
  return capacity;
}








template<class item_t>
bool ArrayList<item_t>::isEmpty() const
{
  if (size==0)
    {
      return true;
    }
  else 
    {
      return false;
    }
}








template <class item_t>
void ArrayList<item_t>::remove(int index)
{
  if (size==1)
    {
      size--;
      return;
    }
  for (int i=index;i<capacity-2;i++)
    {
      items[i]=items[index+1];
    }
  size--;
}








//Make a helper function (RESIZE) that takes the array checks if size == capacity and then resizes the array to be double if true and copies all elements from the old and returns the new one. Also delete the old array in the function.
// USE SIZE FOR THIS FUNCTION AND OTHERS THAT MAKE SENSE TO USE IT IN

template<class item_t>
void ArrayList<item_t>::insert(int index, const item_t& item)
{
  resize();
  if(index==0)
    {
      pushFront(item);   
    }
  else
    {
      for (int i=size;i>index;i--)
	{
	  items[i]=items[i-1];
	}
      items[index-1]=item;
      size+=1;
    }
}





  
// check if size == capacity. double the capacity if so and move elements over to new array then place the entry in the size index 





template<class item_t>
void ArrayList<item_t>::pushBack(const item_t& item)
{
  resize();
  items[size]=item;
  size+=1;
}








//Removes, but does not return, the last item
template<class item_t>   
void ArrayList<item_t>::popBack()
{
  size--;
}










//Returns a reference to the last item (does not remove it)
template<class item_t>
const item_t& ArrayList<item_t>:: getBack() const
{
  return items[size-1];
}










template<class item_t>
void ArrayList<item_t>::pushFront(const item_t& item)
{
  resize();
  for (int i=size;i<0;i--)
    {
      items[i+1]=items[i];
    }
  items[0]=item;
  size++;
}




template<class item_t>
void ArrayList<item_t>:: popFront()
{
  
  for (int i=0;i<size;i++)
    {
      items[i+1]=items[i];
    }
  size--;
}






template<class item_t>
const item_t& ArrayList<item_t>:: getFront() const
{
  return items[0];
}






template<class item_t>
const item_t& ArrayList<item_t>::getItem(int index) const
{
  return items[index];
}






template<class item_t>
void ArrayList<item_t>:: setItem(int index, const item_t& item)
{
  items[index]=item;
}
#endif

// Ask about how testing is supposed to work
// Ask about getBack popBack

// Ask about returning references for get front and get item
// references can just return indexed location
