#define CATCH_CONFIG_MAIN //This will make our main for us :)
#include "catch.hpp"
#include <iostream>
#include "List.h"
#include <string>
#include <fstream>
using namespace std;
/*More info on Catch
Git-Page: https://github.com/philsquared/Catch
*/

//What are we testing today?
#include "Process.cc"

// capture runs the command and remembers the return value and tells you the value you got to compare when all info is printed out in terminal

//Check is a passive version of require that tells whether a test fails but still runs everything. YOU CAN USE REQUIRE FOR EVERYTHING. CHECK THE HW TO SEE IF YOU NEED TO RESIZE THE ARRAY


// if you test set and get functions in other tests that they dont have to be their own separate sections
TEST_CASE("TESTING LinkedList Class")
{
  
  SECTION("Default Constructor")
    {     
      IOBoundProcess test_IOBoundProcess =IOBoundProcess(1);
      //Information to be printed if error (optional stuff)
      INFO("Using default constructor") //Displayed if fails
	
	
	//IF TEST FAIL -- STOP ALL TESTING
	REQUIRE(test_IOBoundProcess.getCPUTime()==0);
      REQUIRE(test_IOBoundProcess.getWaitTime(0)==0);
	
      
    }
  SECTION("GET ID")
    {
       IOBoundProcess test_IOBoundProcess =IOBoundProcess(1);
       REQUIRE(test_IOBoundProcess.getID()==1);
    }
  SECTION("isBlocked")
    {
      IOBoundProcess test_IOBoundProcess =IOBoundProcess(1);
      REQUIRE(test_IOBoundProcess.isBlocked(10)==false);
    }
  SECTION("SIMULATE")
    {
      IOBoundProcess test_IOBoundProcess =IOBoundProcess(1);
      test_IOBoundProcess.simulate(100, 100);
      // what does this equal
    }
}

