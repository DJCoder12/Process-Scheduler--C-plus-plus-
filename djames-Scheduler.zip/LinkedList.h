#ifndef LINKED_LIST_H
#define LINKED_LIST_H
#include "LinkedListNode.h"
#include "List.h"
using namespace std;;

template<class item_t>
class LinkedList:public List<item_t>
{
 public:
  LinkedListNode<item_t>* head;
  LinkedListNode<item_t>*tail;
  int size;
  LinkedList();
  ~LinkedList();
  virtual void pushBack(const item_t& item);   
  //Removes, but does not return, the last item
  virtual void popBack();
  //Returns a reference to the last item (does not remove it).
  virtual const item_t& getBack() const; 
  //Pushes item to the front of the list
  virtual void pushFront(const item_t& item);
  //Removes, but does not return, the first item
  virtual void popFront();
  //Returns a reference to the first item (does not remove it).
  virtual const item_t& getFront() const;
  //Returns a reference to the item at the given index
  virtual const item_t& getItem(int index) const;
  //Sets the item at the given index
  virtual void setItem(int index, const item_t& item);
  //Inserts the given item at the given index
  //(items at index or beyond shift up one position)
  //Inserting just past the last element (i.e. position
  //size) shoud be equivalent to pushBack.
  virtual void insert(int index, const item_t& item);
  //Removes the item at the given index
  //(items beyond index shift down one position)
  virtual void remove(int index);
  //Returns the number of items in the list
  virtual int getSize() const;
  //Returns true if the list is empty (false otherwise)
  virtual bool isEmpty() const;
  //Returns the size of the array that contains the list
};

template<class item_t>
LinkedList<item_t>::LinkedList()
{
  size=0;
  head=nullptr;
  tail=nullptr;
    
}



template<class item_t>
LinkedList<item_t>::~LinkedList()
{
  LinkedListNode<item_t>*curNode=head;
  while(curNode!=nullptr)
    {
      LinkedListNode<item_t>*tempNode=curNode->getNext();
      delete curNode;
      curNode=tempNode;
    }
  head=nullptr;
  tail=nullptr;
  size=0;
}


//Pushes item to the back of the list
template <class item_t>
void LinkedList<item_t>::pushBack(const item_t& item)
{
  if(size==0)
    {
       LinkedListNode<item_t>* newNode= new LinkedListNode<item_t>(nullptr,item);
       head=newNode;
       tail=newNode;
    }
  else if(size==1)
    {
      LinkedListNode<item_t>* newNode= new LinkedListNode<item_t>(nullptr,item);
      head->setNext(newNode);
      tail=newNode;
    }
  else
    {
      LinkedListNode<item_t>* newNode= new LinkedListNode<item_t>(nullptr,item);
      (*tail).setNext(newNode);
      tail=newNode;
    }    
  size++;
}




//Removes, but does not return, the last item
template <class item_t>
void LinkedList<item_t>::popBack()
{
  LinkedListNode<item_t>* newTail=new LinkedListNode<item_t>(head,0);
  LinkedListNode<item_t>* curNode=head;
  while (curNode->getNext()!=tail)
    {
      curNode=curNode->getNext();
      if ((*curNode).getNext()==tail)
	{
	  newTail=curNode;
	}
    }
  newTail=tail;
  size--;
}


//Returns a reference to the last item (does not remove it).
template <class item_t>
const item_t& LinkedList<item_t>::getBack() const
{
  return tail->getItem();
}


//Pushes item to the front of the list
template<class item_t>

void LinkedList<item_t>::pushFront(const item_t& item)
{
  if(size==0)
    {
       LinkedListNode<item_t>* newNode= new LinkedListNode<item_t>(nullptr,item);
       head=newNode;
       tail=newNode;
    }
  else if(size==1)
    {
       LinkedListNode<item_t>* newNode= new LinkedListNode<item_t>(head,item);
       tail=head;
       head=newNode;  
    }
  else
    {
      LinkedListNode<item_t>* newNode= new LinkedListNode<item_t>(head,item);
      head=newNode;
    }
  size++;
}



//Removes, but does not return, the first item
template<class item_t>
void LinkedList<item_t>::popFront()
{
  LinkedListNode<item_t>* newHead=head->getNext();
  delete head;
  head=newHead;
  size--;
}

//Returns a reference to the first item (does not remove it).
template<class item_t>
const item_t& LinkedList<item_t>:: getFront() const
{
  return head->getItem();
}



//Returns a reference to the item at the given index
template<class item_t>
const item_t& LinkedList<item_t>:: getItem(int index) const
{
  LinkedListNode<item_t>* curNode=head;
  int i=0;
  while (i<index)
    {
      curNode=(*curNode).getNext();
      i++;
    }
  return (*curNode).getItem();
}



//Sets the item at the given index
template<class item_t>
void LinkedList<item_t>::setItem(int index, const item_t& item)
{
  LinkedListNode<item_t>*curNode=head;
  for (int i=0;i<index;i++)
    {
      curNode=curNode->getNext();
      i++;
    }
  curNode->setItem(item);
}



//Inserts the given item at the given index
//(items at index or beyond shift up one position)
template<class item_t>
//virtual void insert(int index, const item_t& item);
void LinkedList<item_t>::insert(int index, const item_t& item)
{
  int i=0;
  LinkedListNode<item_t>*curNode=head;
  if (index==0)
    {
      pushFront(item);
    }
  else if (index==size)
    {
      pushBack(item);
    }
  else
    {
      while(curNode!=nullptr && i<index)
	{
	  
	  curNode=curNode->getNext();
	  i++;
	}
      LinkedListNode<item_t>* newNode=new LinkedListNode<item_t>(curNode->getNext(),item);
      (*curNode).setNext(newNode);
      size++;
    }
}

//Removes the item at the given index
//(items beyond index shift down one position)
template<class item_t>
void LinkedList<item_t>:: remove(int index)
{
  LinkedListNode<item_t>*prevNode;
  int i=0;
  if(index==0)
    {
      popFront();
    }
  else if(index==size-1)
    {
      popBack();
    }
  else
    {
      LinkedListNode<item_t>*curNode=head;
      while(i<index-1)
	{
	  curNode->setNext(curNode->getNext());
	  i++;
	  if (i==index-2)
	    {
	      LinkedListNode<item_t>*prevNode=curNode;
	    }
	}
      prevNode->setNext(curNode->getNext());
      delete curNode;
      size--;
    }
}

//Returns the number of items in the list
template<class item_t>
int LinkedList<item_t>::getSize() const
{
  return size;
}
template<class item_t>
//Returns true if the list is empty (false otherwise)
bool LinkedList<item_t>:: isEmpty() const
{
  if (size==0)
    {
      return true;
    }
  else 
    {
      return false;
    }
}
#endif





