#ifndef ROUNDROBIN_H
#define RoundRobin_H

#include "Scheduler.h"
#include "List.h"
class RoundRobin: public Scheduler
{
 protected:
  List<Process*>* procQueue;



 public:

  // Initialize procQueue as an empty ArrayList
  RoundRobin()
    {
      procQueue
    }
  
  //deletes procQueue(not its contents!)
  ~RoundRobin();

  // adds the given process to the back of proQueue
  virtual void addProcess(Process* proc);

  // returns the first un-blocked process in the queue (moving any blocked processes to the back of the queue or zero if all processes are blocked)
  virtual Process* popNext(int curCycle);
  //WRITE THESE METHODS
};
#endif
