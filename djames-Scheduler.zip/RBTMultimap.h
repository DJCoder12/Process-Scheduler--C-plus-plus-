#ifndef RBT_MULTIMAP
#define RBT_MULTIMAP

#include "BSTMultimap.h"
#include "RBTNode.h"
#include <string>
#include <fstream>
#include <queue>
#include <iostream>
#include <map>

using namespace std;

template <class key_t, class val_t>
class RBTMultimap : public BSTMultimap<key_t, val_t>
{
  protected:
   //Performs the rotate left operation
   //(assumes node has a right child)
   virtual void rotateLeft(BSTNode<key_t, val_t>* node);

   //Performs the rotate right operation
   //(assumes node has a left child)
   virtual void rotateRight(BSTNode<key_t, val_t>* node);

   //Fix up the tree after an insert
   //(assumes insertedNode is red)
   virtual void insertFixup(RBTNode<key_t, val_t>* insertedNode);

   //Fix up the tree after deleting a node
   //ReplacementNode is the node that replaced the deleted node
   //(possibly the sentinel)
   virtual void deleteFixup(RBTNode<key_t, val_t>* replacementNode);

   //void transplant(BSTNode<key_t,val_t>* x, BSTNode<key_t,val_t>* y);

   //Puts replacementNode in nodeToReplace's position in the tree
   //(replacementNode takes its children along with it)
   //Assumes nodeToReplace is a real node (not the sentinel)
   virtual void transplant(RBTNode<key_t, val_t>* x, RBTNode<key_t, val_t>* y);

  public:
   //Creates an empty red-black tree
   RBTMultimap();
   virtual ~RBTMultimap();

   //Inserts (key, value) into the multimap
   virtual void insert(const key_t& key, const val_t& value);

   //Removes the key/value pair pointed to by pos
   //(if pos is off the end, does nothing)
   //Returns an iterator pointing to the next node after the
   //deleted node
   virtual BSTForwardIterator<key_t, val_t> remove(const BSTForwardIterator<key_t, val_t>& pos);

   //Prints the tree in the "dot" format for visualization
   //using graphviz
   //NOTE: Requires that keys are streamable (values are not printed)
   virtual void printDOT(std::string filename);
};

//////////////////////////////////////////
//RBTMultimap implementation begins here//
//////////////////////////////////////////

// the key_t and val_t parameters for sentinel are going to use the default constructor of the parameters mentioned. eg if val is string the RBT will have "".

template<class key_t, class val_t>
  RBTMultimap<key_t,val_t>::RBTMultimap()
{
  
  RBTNode<key_t, val_t>* temp=new RBTNode<key_t,val_t>(key_t(),val_t(),true);
  this->sentinel=temp;
  
 
  this->root=this->sentinel;   
  
  this->numItems=0;
}









template <class key_t,class val_t>
  RBTMultimap<key_t,val_t>:: ~RBTMultimap()
{
  this->clear();
  
}

















//virtual void rotateLeft(BSTNode<key_t, val_t>* node);
template<class key_t, class val_t>
  void RBTMultimap<key_t,val_t>::rotateLeft(BSTNode<key_t,val_t>* node)
{
  BSTNode<key_t, val_t>*rotatedNode=node->getRightChild();
  node->setRightChild(node->getLeftChild());
  if (rotatedNode->getLeftChild()!=this->sentinel)

    {
      rotatedNode->getLeftChild()->setParent(node);
    }
  rotatedNode->setParent(node->getParent());
  if (node->getParent()==this->sentinel)
    {
      this->root=rotatedNode;
    }
  else if(node==node->getParent()->getLeftChild())
    {
      node->getParent()->setLeftChild(rotatedNode);
    }
  else
    {
      node->getParent()->setRightChild(rotatedNode);
    }
  rotatedNode->setLeftChild(node);
  node->setParent(rotatedNode);
}


template<class key_t,class val_t>
  void RBTMultimap<key_t, val_t>::rotateRight(BSTNode<key_t, val_t>*node)
{
  BSTNode<key_t, val_t>*rotatedNode=node->getLeftChild();
  node->setLeftChild(rotatedNode->getRightChild());
  if (rotatedNode->getRightChild()!=this->sentinel)
    {
      rotatedNode->getRightChild()->setParent(node);
    }
  rotatedNode->setParent(node->getParent());
  if (node->getParent()==this->sentinel)
    {
      this->root=rotatedNode;
    }
  else if(node==node->getParent()->getLeftChild())
    {
      node->getParent()->setLeftChild(rotatedNode);
    }
  else
    {
      rotatedNode->setLeftChild(node);
    }
  node->setParent(rotatedNode);
}

		

//virtual void transplant(BSTNode<key_t, val_t>* nodeToReplace, BSTNode<key_t, val_t>* replacementNode)










template<class key_t, class val_t>
  void RBTMultimap<key_t,val_t>::insert(const key_t& key,const val_t& val)
{
  RBTNode<key_t,val_t>* newNode=new RBTNode<key_t,val_t>(key,val,true);
  
  this->insertNode(newNode);
 
  this->numItems++;
  
  newNode->setLeftChild(this->sentinel);
  newNode->setRightChild(this->sentinel);
 
  newNode->setColor(true);
  
  insertFixup(newNode);
  
}
















//void insertFixup(RBTNode<key_t, val_t>* insertedNode)
template<class key_t, class val_t>
  void RBTMultimap<key_t,val_t>::insertFixup(RBTNode<key_t,val_t>* insertedNode)
  {
    if(this->numItems<=1)
      {
	return;
      }
    while (insertedNode->getParent()->getColor()==true)
       {
	 if (insertedNode->getParent()==insertedNode->getParent()->getParent()->getLeftChild())
	   {
	     RBTNode<key_t,val_t>* uncle=insertedNode->getParent()->getParent()->getRightChild();
	     if(uncle->getColor()==true)
	       {
		 insertedNode->getParent()->setColor(false);
		 uncle->setColor(false);
		 insertedNode->getParent()->getParent()->setColor(true);
		 insertedNode=insertedNode->getParent()->getParent();
	       }
	   
	     else
	       {
		 if(insertedNode==insertedNode->getParent()->getRightChild())
		   {
		     insertedNode=insertedNode->getParent();
		     rotateLeft(insertedNode);	     
		   }
		 insertedNode->getParent()->setColor(false);
		 insertedNode->getParent()->getParent()->setColor(true);
   		 rotateRight(insertedNode->getParent()->getParent());
	       }
	   }
	 else
	   {
	     RBTNode<key_t,val_t>*uncle=insertedNode->getParent()->getParent()->getLeftChild();
	     if (uncle->getColor()==true)
	       {
		 insertedNode->getParent()->setColor(false);
		 uncle->setColor(false);
		 insertedNode->getParent()->getParent()->setColor(true);
		 insertedNode=insertedNode->getParent()->getParent();
	       }
	     else
	       {
		 if(insertedNode==insertedNode->getParent()->getLeftChild())
		   {
		     insertedNode=insertedNode->getParent();
		     rotateRight(insertedNode);
		   }
		 insertedNode->getParent()->setColor(false);
		 insertedNode->getParent()->getParent()->setColor(true);
		 rotateLeft(insertedNode->getParent()->getParent());
		   }
	   }
       }
     //replacementNode=dynamic_cast<RBTNode<key_t,val_t> * >(this->root);
     dynamic_cast<RBTNode<key_t,val_t> * >(this->root)->setColor(false);
  }	       







//while (insertNode->getParent()->getColor()==true)



template<class key_t,class val_t>
  void RBTMultimap<key_t,val_t>::transplant(RBTNode<key_t,val_t>* x, RBTNode<key_t,val_t>* y)
{
  if (x->getParent()==nullptr)
    {
      this->root=y;
    }
  else if (x==x->getParent()->getLeftChild())
    {
      x->getParent()->setLeftChild(y);
    }
  else
    {
      x->getParent()->setRightChild(y);
      y->setParent(x->getParent());
    }
}








template<class key_t,class val_t>
  BSTForwardIterator<key_t,val_t> RBTMultimap<key_t,val_t>::remove(const BSTForwardIterator<key_t, val_t>&pos)
{
  //if(pos
  return pos;
}



template <class key_t, class val_t>
  void RBTMultimap<key_t,val_t>:: deleteFixup(RBTNode<key_t,val_t>* replacementNode)
{
  while(replacementNode!=this->root && replacementNode->getColor()!=false)
    {
      if (replacementNode==replacementNode->getParent()->getLeftChild())
	{
	  RBTNode<key_t,val_t>*sib=replacementNode->getParent()->getRightChild();
	  if (sib->getColor()==true)
	    {
	      sib->setColor(false);
	      replacementNode->getParent()->setColor(true);
	      rotateLeft(replacementNode->getParent());
	      sib=replacementNode->getParent()->getRightChild();
	    }
	  if(sib->getLeftChild()->getColor()==false && sib->getRightChild()->getColor()==false)
	    {
	      sib->setColor(true);
	      replacementNode=replacementNode->getParent();
	    }
	  else
	    {
	      if (sib->getRightChild()->getColor()==false)
		{
		  sib->getLeftChild()->setColor(false);
		  sib->setColor(true);
		}
	      sib->setColor(replacementNode->getParent()->getColor());
	      replacementNode->getParent()->setColor(false);
	      sib->getRightChild()->setColor(false);
	      rotateLeft(replacementNode->getParent());
	      replacementNode=dynamic_cast<RBTNode<key_t,val_t> * >(this->root);
	      // you need to dynamically cast it
	    }
	}
      else
	{
	  replacementNode->setColor(false);		
	}      
    }
}










template <class key_t, class val_t>
void RBTMultimap<key_t, val_t>::printDOT(std::string filename)
{
   using namespace std;
   ofstream fout(filename.c_str());

   long long counter = 1;
   map<RBTNode<key_t, val_t>*, long long> nodeToCounter;
   nodeToCounter[dynamic_cast<RBTNode<key_t, val_t>* >(this->sentinel)] = counter;
   counter++;

   fout << "digraph RBTMultimap {" << endl;

   fout << "\t node" << nodeToCounter[dynamic_cast<RBTNode<key_t, val_t>* >(this->sentinel)] << " [label=\"nil\", style=filled, color=grey, fontcolor=white];" << endl;

   if(this->root != this->sentinel)
   {
      RBTNode<key_t, val_t>* rt = dynamic_cast<RBTNode<key_t, val_t>* >(this->root);
      if(!nodeToCounter[rt])
      {
	 nodeToCounter[rt] = counter;
	 counter++;
      }
      if(!nodeToCounter[rt->getParent()])
      {
	 nodeToCounter[rt->getParent()] = counter;
	 counter++;
      }
      fout << "\t node" << nodeToCounter[rt] << " -> node" << nodeToCounter[rt->getParent()] << " [constraint=false, tailport=n, headport=s";
      if(rt->getParent() == this->sentinel)
      {
	 fout << ", color=grey];" << endl;
      }
      else
      {
	 //The root's parent is something weird!! Make the arrow orange so it sticks out
	 fout << ", color=orange];" << endl;
      }

      map<RBTNode<key_t, val_t>*, bool> printed;
   
      queue<RBTNode<key_t, val_t>* > q;
      q.push(rt);
      while(!q.empty())
      {
	 RBTNode<key_t, val_t>* node = q.front();
	 q.pop();

	 printed[node] = true;
      
	 //Set up node's appearance
	 if(!nodeToCounter[node])
	 {
	    nodeToCounter[node] = counter;
	    counter++;
	 }
	 fout << "\t node" << nodeToCounter[node] << " [label=\"k: " << node->getKey() << "\", style=filled, color=";
	 if(node->getColor())
	 {
	    fout << "red";
	 }
	 else
	 {
	    fout << "black, fontcolor=white";
	 }
	 fout << "];" << endl;

	 //Set up child links
	 //First the left node
	 if(!nodeToCounter[node->getLeftChild()])
	 {
	    nodeToCounter[node->getLeftChild()] = counter;
	    counter++;
	 }
	 fout << "\t node" << nodeToCounter[node] << " -> node" << nodeToCounter[node->getLeftChild()] << " [tailport=sw";    
	 if(node->getLeftChild() == this->sentinel)
	 {
	    fout << ", color=grey";
	 }
	 else if(printed[node->getLeftChild()])
	 {
	    fout << ", color=orange";
	 }
	 else
	 {
	    q.push(node->getLeftChild());
	 }

	 if(node->getLeftChild() != this->sentinel)
	 {
	    if(node->getLeftChild()->getParent() == node)
	    {
	       //The child's parent pointer points right back,
	       //so draw the second arrow
	       fout << ", dir=both];" << endl;
	    }
	    else
	    {
	       //The child node's parent pointer is not correct!
	       //Draw it in orange so it sticks out
	       fout << "];" << endl;
	       if(!nodeToCounter[node->getLeftChild()->getParent()])
	       {
		  nodeToCounter[node->getLeftChild()->getParent()] = counter;
		  counter++;
	       }
	       fout << "\t node" << nodeToCounter[node->getLeftChild()] << " -> node" << nodeToCounter[node->getLeftChild()->getParent()] << " [tailport=n, color=orange];" << endl;
	    }
	 }
	 else
	 {
	    fout << "];" << endl;
	 }

	 //Now the right node
	 if(!nodeToCounter[node->getRightChild()])
	 {
	    nodeToCounter[node->getRightChild()] = counter;
	    counter++;
	 }
	 fout << "\t node" << nodeToCounter[node] << " -> node" << nodeToCounter[node->getRightChild()] << " [tailport=se";    
	 if(node->getRightChild() == this->sentinel)
	 {
	    fout << ", color=grey";
	 }
	 else if(printed[node->getRightChild()])
	 {
	    fout << ", color=orange";
	 }
	 else
	 {
	    q.push(node->getRightChild());
	 }

	 if(node->getRightChild() != this->sentinel)
	 {
	    if(node->getRightChild()->getParent() == node)
	    {
	       //The child's parent pointer points right back,
	       //so draw the second arrow
	       fout << ", dir=both];" << endl;
	    }
	    else
	    {
	       //The child node's parent pointer is not correct!
	       //Draw it in orange so it sticks out
	       fout << "];" << endl;
	       if(!nodeToCounter[node->getRightChild()->getParent()])
	       {
		  nodeToCounter[node->getRightChild()->getParent()] = counter;
		  counter++;
	       }
	       fout << "\t node" << nodeToCounter[node->getRightChild()] << " -> node" << nodeToCounter[node->getRightChild()->getParent()] << " [tailport=n, color=orange];" << endl;
	    }
	 }
	 else
	 {
	    fout << "];" << endl;
	 }
      }
   }
   fout << "}" << endl;
}

#endif




/*In insert fixup rotate left and rotate right, what are the two parameters?


Is this the proper way to declare the default constructor for sentinel?



Is my rotateRight correct because I took inverse as do the reverse operation and direction for each line?



 */
