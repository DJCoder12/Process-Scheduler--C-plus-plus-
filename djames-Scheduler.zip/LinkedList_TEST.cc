#define CATCH_CONFIG_MAIN //This will make our main for us :)
#include "catch.hpp"
#include <iostream>
#include "List.h"
#include <string>
#include <fstream>
using namespace std;
/*More info on Catch
Git-Page: https://github.com/philsquared/Catch
*/

//What are we testing today?
#include "LinkedList.h"

// capture runs the command and remembers the return value and tells you the value you got to compare when all info is printed out in terminal

//Check is a passive version of require that tells whether a test fails but still runs everything. YOU CAN USE REQUIRE FOR EVERYTHING. CHECK THE HW TO SEE IF YOU NEED TO RESIZE THE ARRAY


// if you test set and get functions in other tests that they dont have to be their own separate sections
TEST_CASE("TESTING LinkedList Class")
{
 
  SECTION("Default Constructor")
    {     
      LinkedList <int>test_linkedlist = LinkedList<int>();

      //Information to be printed if error (optional stuff)
      INFO("Using default constructor") //Displayed if fails
      
      
      //IF TEST FAIL -- STOP ALL TESTING
      REQUIRE(test_linkedlist.getSize() == 0); // Check if true
    }
  
  SECTION("POP BACK")
     {
       LinkedList <int>test_linkedlist = LinkedList<int> (); 
       REQUIRE(test_linkedlist.getSize()==0);
       test_linkedlist.pushFront(10);
       REQUIRE(test_linkedlist.getSize()==1);
       REQUIRE(test_linkedlist.getItem(0)==10);
       test_linkedlist.pushFront(20);
       REQUIRE(test_linkedlist.getItem(0)==20);
       REQUIRE(test_linkedlist.getSize()==2);
       test_linkedlist.popBack();
       REQUIRE(test_linkedlist.getSize()==1);
       REQUIRE(test_linkedlist.getItem(0)==20);
       test_linkedlist.popBack();
       REQUIRE(test_linkedlist.getSize()==0);	 
     }
       
  
   SECTION("GET FRONT")
     {
       LinkedList <int>test_linkedlist = LinkedList<int> ();       
       test_linkedlist.pushFront(10);
       REQUIRE(test_linkedlist.getSize()==1);
       REQUIRE(test_linkedlist.getFront()==10);
       test_linkedlist.pushFront(20);
       REQUIRE(test_linkedlist.getFront()==20);
       REQUIRE(test_linkedlist.getSize()==2);
     }
   SECTION("GET ITEM")
     {
       LinkedList <int>test_linkedlist = LinkedList<int> ();       
       //IF TEST FAIL -- CONTINUE TESTING
       test_linkedlist.pushFront(10);
       REQUIRE(test_linkedlist.getSize()==1);
       REQUIRE(test_linkedlist.getItem(0)==10);
       test_linkedlist.pushFront(20);
       REQUIRE(test_linkedlist.getItem(0)==20);
       REQUIRE(test_linkedlist.getSize()==2);
     }
   
   SECTION("SET ITEM")
     {
        LinkedList <int>test_linkedlist = LinkedList<int> ();       
       //IF TEST FAIL -- CONTINUE TESTING
       test_linkedlist.pushFront(10);
       REQUIRE(test_linkedlist.getSize()==1);
       test_linkedlist.pushFront(20);
       test_linkedlist.setItem(0,11);
       test_linkedlist.setItem(1,25);
       REQUIRE(test_linkedlist.getItem(0)==11);
       REQUIRE(test_linkedlist.getItem(1)==25);
       
     }
   
   SECTION("PUSH FRONT")
     {
       LinkedList <int>test_linkedlist = LinkedList<int> ();       
       //IF TEST FAIL -- CONTINUE TESTING
       test_linkedlist.pushFront(10);
       REQUIRE(test_linkedlist.getSize()==1);
       REQUIRE(test_linkedlist.getItem(0)==10);
       test_linkedlist.pushFront(20);
       REQUIRE(test_linkedlist.getItem(0)==20);
       REQUIRE(test_linkedlist.getSize()==2);
     }
   
   SECTION("REMOVE")
     {
       LinkedList <int>test_linkedlist = LinkedList<int> ();       
       //IF TEST FAIL -- CONTINUE TESTING
       test_linkedlist.pushBack(5);
       test_linkedlist.pushBack(6);
       test_linkedlist.pushBack(7);
       REQUIRE(test_linkedlist.getSize()==3);
       REQUIRE(test_linkedlist.getItem(0)==5);
       test_linkedlist.remove(0);
       REQUIRE(test_linkedlist.getSize()==2);
       REQUIRE(test_linkedlist.getItem(0)==6);
       test_linkedlist.remove(0);
       REQUIRE(test_linkedlist.getItem(0)==7);
       test_linkedlist.remove(0);
       REQUIRE(test_linkedlist.isEmpty()==true);
       
     }
     
   SECTION("INSERTION")
     {
       LinkedList <int>test_linkedlist = LinkedList<int> ();       
       //IF TEST FAIL -- CONTINUE TESTING
       REQUIRE(test_linkedlist.getSize()==0);
       test_linkedlist.insert(0,5);
       REQUIRE(test_linkedlist.getSize()==1);
       REQUIRE(test_linkedlist.getItem(0)==5);
       test_linkedlist.remove(0);
       REQUIRE(test_linkedlist.getSize()==0);
       
     }
   
   SECTION("PUSHBACK")
     {
       LinkedList <int>test_linkedlist = LinkedList<int> (); 
       test_linkedlist.pushBack(10);
       REQUIRE(test_linkedlist.getSize()==1);
       REQUIRE(test_linkedlist.getItem(0)==10);
       test_linkedlist.pushBack(20);
       REQUIRE(test_linkedlist.getItem(1)==20);
       REQUIRE(test_linkedlist.getSize()==2);
     }
   
   SECTION("GET SIZE")
     {
       LinkedList <int>test_linkedlist = LinkedList<int> (); 
       test_linkedlist.pushBack(10);
       test_linkedlist.pushBack(10);
       test_linkedlist.pushBack(10);
       test_linkedlist.pushBack(10);
       test_linkedlist.pushBack(10);
       test_linkedlist.pushBack(10);
       REQUIRE(test_linkedlist.getSize()==6);
     }
   
   SECTION("IsEmpty")
     {
       LinkedList <int>test_linkedlist = LinkedList<int> (); 
       test_linkedlist.pushBack(10);
       test_linkedlist.pushBack(20);
       test_linkedlist.popBack();
       test_linkedlist.popBack();
       REQUIRE(test_linkedlist.isEmpty()== true);
       test_linkedlist.pushFront(10);
       test_linkedlist.pushFront(20);
       test_linkedlist.popFront();
       test_linkedlist.popFront();
       REQUIRE(test_linkedlist.isEmpty()== true);
     }
  
}
