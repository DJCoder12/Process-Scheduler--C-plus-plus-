#include "ArrayList.h"
#include "Scheduler.h"
#include "simulate.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include<cstdio>
using namespace std;
int main(int argc, char** argv)
{
  
  if(argc <3)
    {
      cout<<"There are not enough arguments given"<<endl;
      cout<<"ARGUMENT 1 is the number of cpu bound processes"<<endl;
      cout<<"ARGUMENT 2 is the number of I/O bound processes"<<endl;
      cout<<"ARGUMENT 3 is the number of CYCLES TO Simulate"<<endl;
      return 0;
    }
  else
    {
  
      RoundRobin* rr=new RoundRobin();
      FastRoundRobin* rr2=new FastRoundRobin();
      CompletelyFair* cf=new CompletelyFair();
      //FastCompletelyFair* fcf=new FastCompletelyFair();
      
      double* results=new double[5];
      double* results2=new double[5];
      double* results3= new double[5];
      //double* results4=new double[5];
      

     
 

      

      results=simulate(rr,stoi(argv[1]),stoi(argv[2]),stoi(argv[3]));

      cout<<"THE FOLLOWING ARE THE ROUNDROBIN RESULTS:"<<endl;
      cout<<"This is the number of nano seconds predicted compared to actual number of nano seconds "<<results[0]<<endl;
      cout<<"This is the average cpu time of all CPU Bound Processes "<<results[1]<<endl;
      cout<<"This is the average wait time of all CPU Bound Processes"<<results[2]<<endl;
      cout<<"This is the average CPU time of all I/O bound processes"<<results[3]<<endl;
      cout<<"---------------------------------------------------------------"<<endl;


  


      cout<<"THE FOLLOWING ARE THE FAST ROUNDROBIN RESULTS"<<endl;
      results2=simulate(rr2 ,stoi(argv[1]),stoi(argv[2]),stoi(argv[3]));
      cout<<"This is the number of nano seconds predicted compared to actual number of nano seconds "<<results2[0]<<endl;
      cout<<"This is the average cpu time of all CPU Bound Processes "<<results2[1]<<endl;
      cout<<"This is the average wait time of all CPU Bound Processes"<<results2[2]<<endl;
      cout<<"This is the average CPU time of all I/O bound processes"<<results2[3]<<endl;
      cout<<"-------------------------------------------------------------------"<<endl;





      


      cout<<"THE FOLLOWING ARE THE COMPLETELY FAIR"<<endl;
      results3=simulate(cf,stoi(argv[1]),stoi(argv[2]),stoi(argv[3]));
      cout<<"THE FOLLOWING ARE THE COMPLETLEY FAIR RESULTS:"<<endl;
      cout<<"This is the number of nano seconds predicted compared to actual number of nano seconds "<<results3[0]<<endl;
      cout<<"This is the average cpu time of all CPU Bound Processes "<<results3[1]<<endl;
      cout<<"This is the average wait time of all CPU Bound Processes"<<results3[2]<<endl;
      cout<<"This is the average CPU time of all I/O bound processes"<<results3[3]<<endl;
      cout<<"-------------------------------------------------------------------"<<endl;


      return 0;
      
    }
}


      /*

       cout<<"THE FOLLOWING ARE THE FAST COMPLETELY FAIR"<<endl;
       results4=simulate(fcf,stoi(argv[1]),stoi(argv[2]),stoi(argv[3]));
      cout<<"THE FOLLOWING ARE THE FAST COMPLETLEY FAIR RESULTS:"<<endl;
      cout<<"This is the number of nano seconds predicted compared to actual number of nano seconds "<<results4[0]<<endl;
      cout<<"This is the average cpu time of all CPU Bound Processes "<<results4[1]<<endl;
      cout<<"This is the average wait time of all CPU Bound Processes"<<results4[2]<<endl;
      cout<<"This is the average CPU time of all I/O bound processes"<<results4[3]<<endl;
     
    }
      */	


