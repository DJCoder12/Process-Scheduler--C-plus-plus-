#ifndef BSTNODE_H
#define BSTNODE_H


using namespace std;

template<class key_t ,class val_t>

  class BSTNode
{
 public:
  BSTNode<key_t,val_t>* leftChild;
  BSTNode<key_t,val_t>* rightChild;
  BSTNode<key_t,val_t>* parent;
  key_t key;
  val_t value;

  BSTNode(const key_t& key,const val_t& value);
  BSTNode();
  virtual ~BSTNode();
  virtual const val_t& getValue() const;
  virtual void setValue(const val_t& value);

  virtual const key_t& getKey() const;
  virtual void setKey(const key_t& key);

  virtual BSTNode<key_t,val_t>* getLeftChild() const;
  virtual void setLeftChild(BSTNode<key_t,val_t>* newLeftChild);

  virtual BSTNode<key_t,val_t>* getRightChild() const;
  virtual void setRightChild(BSTNode<key_t,val_t>* newRightChild);
  
  virtual BSTNode<key_t,val_t>* getParent() const;
  virtual void setParent(BSTNode<key_t, val_t>* parent);
};





template <class key_t,class val_t>
  BSTNode<key_t,val_t>:: BSTNode(const key_t& key,const val_t& value)
{
  leftChild=nullptr;
  rightChild=nullptr;
  parent=nullptr;
  this->key=key;
  this->value=value;
  // just using the variable is fine for the assignments
}

template<class key_t, class val_t>
  BSTNode<key_t,val_t>:: ~BSTNode()
{
 
}

template<class key_t,class val_t>
  BSTNode<key_t,val_t>:: BSTNode()
{
  leftChild=nullptr;
  rightChild=nullptr;
  parent=nullptr;
  this->key=0;
  this->value=0;
}

template<class key_t, class val_t>
  const val_t& BSTNode<key_t,val_t>::getValue() const
{
  return value;
}



template<class key_t,class val_t>
  void BSTNode<key_t,val_t>::setValue(const val_t& val)
{
  value=val;
}



template<class key_t,class val_t>
  const key_t& BSTNode<key_t,val_t>::getKey() const
{
  return key;
}

template<class key_t,class val_t>
  void BSTNode<key_t,val_t>::setKey(const key_t& newKey)
{
  key=newKey;
}

template<class key_t,class val_t>
  BSTNode<key_t,val_t>* BSTNode<key_t,val_t>::getLeftChild() const
{
  return leftChild;
}

template<class key_t,class val_t>
  void BSTNode<key_t,val_t>::setLeftChild(BSTNode<key_t,val_t>* newLeftChild)
{
  leftChild=newLeftChild;
}

template<class key_t,class val_t>
  BSTNode<key_t,val_t>* BSTNode<key_t,val_t>::getRightChild() const
{
  return rightChild;
}




//void setRightChild(BSTNode<key_t,val_t>* newRightChild);

template<class key_t,class val_t>
  void BSTNode<key_t,val_t>::setRightChild(BSTNode<key_t,val_t>* newRightChild)
{
  rightChild=newRightChild;
}





template<class key_t, class val_t>
  BSTNode<key_t,val_t>* BSTNode<key_t,val_t>::getParent() const
{
  return parent;
}


template<class key_t,class val_t>
  void BSTNode<key_t,val_t>::setParent(BSTNode<key_t,val_t>* newParent)
{
  parent=newParent;
}
  
#endif
/*
// how do i accomodate for having 2 arguments in my template? YOU DID :)
// why is my identation off? EMACS IS WEIRD 
// can i check if the node pointer of getchild is a null pointer using ==nullptr
THIS IS VALID BECAUSE nullptr is NULL and NULL IS 0








const val_t& getValue();
  void setValue(const val_t& value);
  const key_t& getKey();
  void setKey(const key_t& key);
  BSTNode getLChild();
  void setLChild(BSTNode lChild);
  BSTNode getRChild();
  void setRChild(BSTNode rChild);
  BSTNode getParent();
  void setParent(BSTNode parent);
*/



















  
